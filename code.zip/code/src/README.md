# Readme


 - there are 4 basic routes:
   - `/` for home page
   - `/section/:section` for filtering books by section
   - `/bookdetailspage/:id` for showing book by ID
   - `*` for 404 page. (using * as path will show 404 page automatically)
 - Make sure to follow classes carefully
 - this is just boilerplate feel free to change structure however you want, add new styles, classes or any new feature