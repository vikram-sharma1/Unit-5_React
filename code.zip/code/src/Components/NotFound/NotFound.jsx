export const NotFound = () => {
  return (
    <div className="notFound">
      <img src="https://i.stack.imgur.com/6M513.png" alt=""></img>
    </div>
  );
};
