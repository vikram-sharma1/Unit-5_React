export const NotFound = () => {
  return <div className="notFound">
    {/* Show some 404 not found image or component here */}
    <img src="https://i.stack.imgur.com/6M513.png" alt="" />
  </div>
};
